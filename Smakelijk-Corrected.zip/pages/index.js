
import Head from 'next/head';

export default function Home() {
  return (
    <div className="min-h-screen bg-pink-50 p-4 flex flex-col items-center">
      <Head>
        <title>Småkelijk</title>
      </Head>
      <div className="text-center mt-6">
        <img src="/logo.png" alt="Småkelijk logo" className="w-48 mx-auto mb-4" />
        <h1 className="text-4xl font-bold text-teal-700">Welkom bij Småkelijk</h1>
        <p className="text-lg mt-2 text-gray-700 max-w-xl mx-auto">
          Huisgemaakte maaltijden, met liefde bereid en klaar voor afhalen bij de opvang.
        </p>
      </div>

      <div className="w-full max-w-md mt-8 shadow-xl bg-white rounded-xl p-6">
        <h2 className="text-2xl font-semibold text-teal-700 mb-2">Vandaag op het menu</h2>
        <img
          src="/meal-today.jpg"
          alt="Pasta maaltijd"
          className="rounded-xl mb-4"
        />
        <p className="text-gray-800 mb-2">Romige pasta met gegrilde groenten en een vleugje citroen.</p>
        <p className="text-sm text-gray-600">Ophalen tussen 17:00–17:30 bij het kinderdagverblijf.</p>

        <div className="mt-4 flex flex-col gap-2">
          <label className="text-sm text-gray-700" htmlFor="quantity">Aantal maaltijden:</label>
          <input
            id="quantity"
            type="number"
            min="1"
            defaultValue="1"
            className="border border-gray-300 p-2 rounded-lg w-full"
          />
          <button className="bg-teal-600 hover:bg-teal-700 text-white text-lg py-2 px-4 rounded-lg mt-4">
            Bestel nu & betaal met iDEAL
          </button>
        </div>
      </div>
    </div>
  );
}
