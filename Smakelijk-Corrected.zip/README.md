# Småkelijk

This is a Next.js-based food ordering site for Anna's home-cooked meals.